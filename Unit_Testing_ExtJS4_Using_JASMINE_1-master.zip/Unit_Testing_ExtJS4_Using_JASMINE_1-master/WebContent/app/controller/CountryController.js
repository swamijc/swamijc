Ext.define("UT.controller.CountryController",{
	extend : "Ext.app.Controller",
	models : ["Country"],
	stores : ["CountryStore"],
	views : ["CountryCombo"]
});