Ext.define("UT.model.Country",{
	extend : "Ext.data.Model",
	fields : ["name","capital"]
});