package org.structural.pattern.composite;

public interface Component {

	public void receiveNotification(String notification);

}
