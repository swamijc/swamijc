package org.structural.pattern.flyweight;

public enum BALL_COLOR {
	BLUE,
	BLACK,
	RED,
	GREEN;
}
