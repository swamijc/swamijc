package org.structural.pattern.facade;

public interface Validatable{

	public boolean validate(int number) throws Exception;

}
