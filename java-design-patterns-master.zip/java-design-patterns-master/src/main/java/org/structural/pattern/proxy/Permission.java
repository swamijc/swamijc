package org.structural.pattern.proxy;

public interface Permission {

	public void confidentialOperation();

}
