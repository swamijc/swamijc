package org.structural.pattern.bridge;

//Concrete Implementation
public class AirtelSimCard implements SimCard{

	@Override
	public void callService() {
		// TODO : call service
	}

	@Override
	public void smsService() {
		// TODO :: sms service
	}
}
