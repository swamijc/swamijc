package org.structural.pattern.decorator;

public interface URLRequest {

	public Object getValue(String url) throws SecurityException;

}
