package org.structural.pattern.bridge;

//implementation interface
public interface SimCard {

	public  void callService();

	public void smsService();

}
