package org.creational.pattern.abstractfactory;

public class ChevroletBeat  extends Car{

	@Override
	public void driveCar() {
		return;
	}

}
