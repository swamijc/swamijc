package org.creational.pattern.abstractfactory;

public abstract class Car {

	public abstract void driveCar();

}
