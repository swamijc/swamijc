package org.creational.pattern.abstractfactory;

public interface CarFactory {

	public Car produceCar();
	
}
