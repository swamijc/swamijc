package org.creational.pattern.abstractfactory;

public class FordFigo  extends Car{

	@Override
	public void driveCar() {
		return;
	}

}
