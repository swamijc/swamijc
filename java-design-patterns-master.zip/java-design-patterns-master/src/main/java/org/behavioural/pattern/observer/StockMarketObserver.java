package org.behavioural.pattern.observer;

public interface StockMarketObserver {

	public void latestStockMarketPrice(double currentPrice);

}
