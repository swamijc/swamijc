package org.behavioural.pattern.state;

public interface Arithmatic {

	public int calculate(int a, int b);

}
