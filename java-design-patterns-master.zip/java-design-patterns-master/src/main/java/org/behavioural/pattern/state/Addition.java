package org.behavioural.pattern.state;

public class Addition implements Arithmatic{

	@Override
	public int calculate(int a, int b) {
		return a+b;
	}

}
