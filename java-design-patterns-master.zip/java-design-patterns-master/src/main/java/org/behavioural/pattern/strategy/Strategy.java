package org.behavioural.pattern.strategy;

public interface Strategy {

	public double calculateInterest(double principle, int rate, int time);

}
