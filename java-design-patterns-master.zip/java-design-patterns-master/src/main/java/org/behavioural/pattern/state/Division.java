package org.behavioural.pattern.state;

public class Division implements Arithmatic{

	@Override
	public int calculate(int a, int b) {
		return a/b;
	}

}
