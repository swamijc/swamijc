package org.behavioural.pattern.state;

public class Multiplication implements Arithmatic{

	@Override
	public int calculate(int a, int b) {
		return a*b;
	}

}
