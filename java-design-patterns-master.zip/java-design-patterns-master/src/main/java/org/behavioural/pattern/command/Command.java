package org.behavioural.pattern.command;

public interface Command {

	public void execute();

}
